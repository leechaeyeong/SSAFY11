package baekjoon;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main_16234_�α��̵� {

    static int[] dx = {1, -1, 0, 0};
    static int[] dy = {0, 0, 1, -1};
    static int l, r, res = 0;
    static class Pair {
        int x, y;
 
        public Pair(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }
    public static void main(String[] args) throws Exception {
       Scanner sc= new Scanner(System.in);
        int n = sc.nextInt();
        l = sc.nextInt();
        r = sc.nextInt();
        
        int[][] map = new int[n + 1][n + 1];
        boolean[][] visited = new boolean[n + 1][n + 1];
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                map[i][j] = sc.nextInt();
            }
        }
        boolean next = false;  
        while (!next) {
            Queue<Pair> q = new LinkedList<>();
            int sum = 0, cnt = 0;                           
            ArrayList<Pair> list = new ArrayList<>();      
            
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= n; j++) {
                	
                    q.add(new Pair(i, j));
                    
                    while (!q.isEmpty()) {
                        Pair p = q.poll();
                        if (!visited[p.x][p.y]) {
                            visited[p.x][p.y] = true;
                            cnt++;
                            sum += map[p.x][p.y];
                            
                            list.add(new Pair(p.x, p.y));
                            
                            for (int k = 0; k < 4; k++) {
                                int nx = p.x + dx[k];
                                int ny = p.y + dy[k];
                                if (nx > 0 && nx <= n && ny > 0 && ny <= n )
                                	if(!visited[nx][ny] && checkfunc(map[p.x][p.y], map[nx][ny])) {
                                    q.add(new Pair(nx, ny));
                                }
                            }
                        }
                    }
 
                    
                    if (list.size() > 1) {
                        int tsum = sum / cnt;
                        for (int k = 0; k < list.size(); k++) {
                            Pair p = list.get(k);
                            map[p.x][p.y] = tsum;
                        }
                        next = true;
                    }
                    
                    list = new ArrayList<>();
                    sum = 0;
                    cnt = 0;
                }
            }   
            
            if (next) {        
                res++;
                next = false;
                visited = new boolean[n + 1][n + 1];
            } else break;
        }
        System.out.println(res);
    }
 

    public static boolean checkfunc(int q, int qq) {
        int check = Math.abs(q - qq);
        if (check >= l && check <= r) return true;
        else return false;
    }
 

}// end of class
