

public class ProductTest {
	public static void main(String[] args) {
		//제품 정보저장
		TV tv = new TV(0, "텔레비전", 50, 1, 30, "led");
		Refrigerator r = new Refrigerator(1, "냉장고", 60, 1, 100);
		
		
		
		//제품 정보출력 
		System.out.println(tv.toString());
		System.out.println(r.toString());
	}
}
