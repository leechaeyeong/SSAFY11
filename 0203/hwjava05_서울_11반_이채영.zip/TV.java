
public class TV {
	private int serialNum;
	private String name;
	private int cost;
	private int count;
	private int inch;
	private String type;
	
	public TV(int serialNum, String name, int cost, int count, int inch, String type) {
		super();
		this.serialNum = serialNum;
		this.name = name;
		this.cost = cost;
		this.count = count;
		this.inch = inch;
		this.type = type;
	}
	
	public String toString() {
		return "TV [serialNum=" + serialNum + ", name=" + name + ", cost=" + cost + ", count=" + count + ", inch="
				+ inch + ", type=" + type + "]";
	}
	
	public int getSerialNum() {
		return serialNum;
	}
	public void setSerialNum(int serialNum) {
		this.serialNum = serialNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getInch() {
		return inch;
	}
	public void setInch(int inch) {
		this.inch = inch;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
