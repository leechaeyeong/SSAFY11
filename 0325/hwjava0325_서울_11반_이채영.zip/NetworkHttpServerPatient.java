package app;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import medical.Hospital;
import person.Patient;

public class NetworkHttpServerPatient {
	public static void main(String[] args) throws IOException {
		
		Patient p1 = new Patient("��ȭȭ", 78, "010-1111-1111", "����", "001", true);
		Patient p2 = new Patient("��åå", 40, "010-2222-2222", "��������", "001", true);
		Patient p3 = new Patient("������", 54, "010-3333-3333", "����", "901", false);
		Patient p4 = new Patient("������", 99, "010-4444-4444", "�Ӿ���", "001", false);
	
		
		// ȯ�� Collection
		List<Patient> patientList = new ArrayList<Patient>();
		patientList.add(p1);
		patientList.add(p2);
		patientList.add(p3);
		patientList.add(p4);
				
		StringBuilder sb = new StringBuilder();
		sb.append("<html><body><h2>ȯ�� ����</h2><table style='border: 1px solid green;'>");
		for( Patient h : patientList ) {
			StringBuilder name = new StringBuilder();
			name.append(h.getName());
			name.replace(1, name.length(), "XX");
			
			StringBuilder tel = new StringBuilder();
			tel.append(String.valueOf(h.getPhone()));
			tel.replace(9, tel.length(), "XXXX");
			
			
			sb.append("<tr style='border: 1px solid green;'><td>").append(name).append("</td><td>").append(tel).append("</td></tr>");
		}
		sb.append("</table></body></html>");
		String html = sb.toString();
		
		try (ServerSocket ss = new ServerSocket(8090)) {
			System.out.println("[Patient Info Server is ready]");
			
			while (true) {
				try ( Socket socket = ss.accept() ) {

					BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));

					bw.write("HTTP/1.1 200 OK \r\n");
					bw.write("Content-Type: text/html;charset=utf-8\r\n");
					bw.write("Content-Length: " + html.length() + "\r\n");
					bw.write("\r\n");
					bw.write(html);
					bw.write("\r\n");
	                bw.flush();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
