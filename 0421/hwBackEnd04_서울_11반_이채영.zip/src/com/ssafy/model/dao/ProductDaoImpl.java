package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.model.ProductDto;
import com.ssafy.util.DBUtil;

public class ProductDaoImpl implements ProductDao{

	@Override
	public void insertProduct(String name, int price, String comment) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into products (pname, price, pcomment) \n");
			sql.append("values (?, ?, ?)");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, name);
			pstmt.setInt(2, price);
			pstmt.setString(3, comment);
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}		

	@Override
	public ProductDto searchProduct(int no) throws SQLException {
		ProductDto productDto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select pcode, pname, price, pcomment \n");
			sql.append("from products \n");
			sql.append("where pcode = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				productDto = new ProductDto();
				productDto.setPcode(rs.getInt("pcode"));
				productDto.setPname(rs.getString("pname"));
				productDto.setPrice(rs.getInt("price"));
				productDto.setPcomment(rs.getString("pcomment"));
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return productDto;
		}

	@Override
	public List<ProductDto> searchList() throws SQLException {
		List<ProductDto> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select pcode, pname, price, pcomment \n");
			sql.append("from products \n");
			pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
			while(rs.next()) {
				ProductDto productDto = new ProductDto();
				productDto.setPcode(rs.getInt("pcode"));
				productDto.setPname(rs.getString("pname"));
				productDto.setPrice(rs.getInt("price"));
				productDto.setPcomment(rs.getString("pcomment"));	
				list.add(productDto);
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return list;
	}

	@Override
	public void deleteProduct(int no) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("delete from products \n");
			sql.append("where pcode = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, no);
			int successCnt = pstmt.executeUpdate();
			if(successCnt == 0)
				throw new SQLException();
				
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

	@Override
	public List<ProductDto> searchListOpt(String key, String word) throws SQLException {
		List<ProductDto> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select pcode, pname, price, pcomment \n");
			sql.append("from products \n");
			
			if(key.equals("name")) { 
				sql.append("where pname like ?");
			}else { 
				sql.append("where price <= ?");
			}
			
			pstmt = conn.prepareStatement(sql.toString());
			if(key.equals("name")) { 
				pstmt.setString(1, "%"+word+"%");
			}else {
				pstmt.setInt(1, Integer.parseInt(word));
			}

			rs = pstmt.executeQuery();
			while(rs.next()) {
				ProductDto productDto = new ProductDto();
				productDto.setPcode(rs.getInt("pcode"));
				productDto.setPname(rs.getString("pname"));
				productDto.setPrice(rs.getInt("price"));
				productDto.setPcomment(rs.getString("pcomment"));	
				list.add(productDto);
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return list;
	}
}
