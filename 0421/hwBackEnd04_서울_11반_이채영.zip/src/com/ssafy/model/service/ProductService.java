package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.ProductDto;

public interface ProductService {

	public void insertProduct(String name, int price, String comment) throws SQLException;
	public ProductDto searchProduct(int no) throws SQLException;
	public List<ProductDto> searchList() throws SQLException;
	public void deleteProduct(int no) throws SQLException;
	public List<ProductDto> searchListOpt(String key, String word) throws SQLException;
}
