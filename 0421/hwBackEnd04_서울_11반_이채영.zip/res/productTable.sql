create table products (
pcode int primary key auto_increment,
pname varchar(40),
price int,
pcomment varchar(200)
);