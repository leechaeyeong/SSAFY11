package com.ssafy.vue.service;

import java.util.List;

import com.ssafy.vue.dto.Hrm;

public interface HrmService {
	public List<Hrm> retrieveHrm();
//	public Hrm detailBoard(int no);
	public boolean writeHrm(Hrm hrm);
//	public boolean updateBoard(Hrm board);
//	public boolean deleteBoard(int no);
}
