<template>
  <div>

          <!-- 검색창 : <input type="text" v-model="searchword"> <button @click="search">검색</button> -->

          <div v-if="items.length">
              <table style=" width: 50%; ">
                <tr style="background-color: rgb(71, 115, 180); color: white;">
                  <th>사원 아이디</th>
                  <th>사원명</th>
                  <th>부서</th>
                  <th>직책</th>
                  <th>연봉</th>
                </tr>
                <tr v-for="(emp, index) in items" :key="index + '_items'">
                  <td>{{emp.id}}</td>
                  <td>{{emp.name}}</td>
                  <td>{{emp.dept}}</td>
                  <td>{{emp.position}}</td>
                  <td>{{emp.sal}}</td>
                </tr>
              </table>
          </div>
          <div v-else>
              등록된 사원이 없습니다
          </div>

    </div>

</template>

<script>
import axios from 'axios';


export default {
    name: 'List'
    , data: function(){
          return {
            items: []
           , searchword:""
          }
    }
     , created() {
          axios.get('http://localhost:9999/vue/api/hrm').then(({ data }) => {
           this.items = data;
           });
                   
        } 
    //  , methods:{
          //       search(){
          //           let word2 = this.searchword;
          //           this.items = this.items.filter(function(val, idx){
          //               if(val.name.indexOf(word2) > -1){
          //                   return true;
          //               }
          //           });
          //       }
          // } // end of methods

}
</script>

<style>

</style>