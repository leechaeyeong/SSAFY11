<template>
   <div>
        <table>
            <tr>
                <td id="tds">이름</td>
                <td><input type="text" id="name" v-model="name"></td>
            </tr>
            <tr>
                <td id="tds">이메일</td>
                <td><input type="text" id="email" v-model="email"></td>
            </tr>
            <tr>
                <td id="tds">고용일</td>
                <td><input type="text" id="hiredate" v-model="hiredate" placeholder="연도-월-일"></td>
            </tr>
            <tr>
                <td id="tds">관리자</td>
                <td><input type="text" id="admin"  v-model="admin"></td>
            </tr>
            <tr>
                <td id="tds">직책</td>
                <td>
                    <select v-model="position">
                        <option value="">선택하세요</option>
                        <option value="1">사장</option>
                        <option value="2">기획부장</option>
                        <option value="3">영업부장</option>
                        <option value="4">총무부장</option>
                        <option value="5">인사부장</option>
                        <option value="6">과장</option>
                        <option value="7">영업대표이사</option>
                        <option value="8">사원</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td id="tds">부서</td>
                <td><input type="text" id="dept"  v-model="dept"></td>
            </tr>
            <tr>
                <td id="tds">월급</td>
                <td><input type="text" id="sal"  v-model="sal"></td>
            </tr>
            <tr>
                <td id="tds">커미션</td>
                <td><input type="text" id="commision"  v-model="commision"></td>
            </tr>
        </table>
        <div>
            <button class="btn btn-primary" @click="regist">등록</button>
            <button class="btn btn-primary" @click="moveList">목록</button>
        </div>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    name: 'Create'
    , data: function(){
        return {
            id :''
            ,name :''
            , email : ''
            , hiredate : ''
            , admin : ''
            ,position :''
            ,dept : ''
            ,sal : ''
            ,commision : ''
        };
    }
    , methods: {
        regist (){
            axios
                .post('http://localhost:9999/vue/api/hrm', { 
                    id : this.id
                    , name: this.name
                    , email: this.email
                    , hiredate: this.hiredate
                    , admin: this.admin
                    , position: this.position
                    , dept: this.dept
                    , sal: this.sal
                    , commision: this.commision
                })
                .then(({ data }) => {
                let msg = '등록 처리시 문제가 발생했습니다.';
                if (data === 'success') {
                    msg = '등록이 완료되었습니다.';
                }
                alert(msg);
                this.moveList();
                });
            },
            moveList(){
                 this.$router.push('/list');
            }
    }
}
</script>

<style>

</style>