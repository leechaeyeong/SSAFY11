export default {
    template: `
    <div>
        <table>
            <tr>
                <td id="tds">이름</td>
                <td><input type="text" id="name" v-model="name"></td>
            </tr>
            <tr>
                <td id="tds">이메일</td>
                <td><input type="text" id="email" v-model="email"></td>
            </tr>
            <tr>
                <td id="tds">고용일</td>
                <td><input type="text" id="hiredate" v-model="hiredate" placeholder="연도-월-일"></td>
            </tr>
            <tr>
                <td id="tds">관리자</td>
                <td><input type="text" id="admin"  v-model="admin"></td>
            </tr>
            <tr>
                <td id="tds">직책</td>
                <td>
                    <select v-model="position">
                        <option value="">선택하세요</option>
                        <option value="1">사장</option>
                        <option value="2">기획부장</option>
                        <option value="3">영업부장</option>
                        <option value="4">총무부장</option>
                        <option value="5">인사부장</option>
                        <option value="6">과장</option>
                        <option value="7">영업대표이사</option>
                        <option value="8">사원</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td id="tds">부서</td>
                <td><input type="text" id="dept"  v-model="dept"></td>
            </tr>
            <tr>
                <td id="tds">월급</td>
                <td><input type="text" id="sal"  v-model="sal"></td>
            </tr>
            <tr>
                <td id="tds">커미션</td>
                <td><input type="text" id="commision"  v-model="commision"></td>
            </tr>
        </table>
        <div>
            <button class="btn btn-primary" @click="regist">등록</button>
            <button class="btn btn-primary" @click="moveList">목록</button>
        </div>
    </div>
    `,
    data: function(){
        return {
            name :''
            , email : ''
            , hiredate : ''
            , admin : ''
            ,position :''
            ,dept : ''
            ,sal : ''
            ,commision : ''
        };
    }
    , methods: {
        regist (){
                const emp = localStorage.getItem('emp');
                let newEmp = {
                    items:[]
                };
                if(emp){
                    newEmp = JSON.parse(emp);
                }
                
                newEmp.items.push({
                    name: this.name
                    , email: this.email
                    , hiredate: this.hiredate
                    , admin: this.admin
                    , position: this.position
                    , dept: this.dept
                    , sal: this.sal
                    , commision: this.commision
                })
                var input = JSON.stringify(newEmp);
            // console.log(input);
                localStorage.setItem('emp', input);
                alert("등록 완료!");
                location.href = './hrm_list.html';
            },
            moveList(){
                location.href = "hrm_list.html";
            }
    }
};