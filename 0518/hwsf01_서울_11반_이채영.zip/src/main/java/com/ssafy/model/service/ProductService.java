package com.ssafy.model.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;

@Service
public interface ProductService {

	public List<Product> selectAll();
	

	public ProductRepo getRepo();
	
	public Product select(String id);

	public int insert(String id);
	
	public int update(Product product);
	
	public int delete(String id) ;

}
