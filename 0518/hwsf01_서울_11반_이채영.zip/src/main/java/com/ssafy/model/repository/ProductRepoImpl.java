package com.ssafy.model.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.Product;

@Repository
public class ProductRepoImpl implements ProductRepo {

	public List<Product> selectAll() {
		List<Product> list = new ArrayList<Product>();
		System.out.println("This is ProductRepoImpl - selectAll()");
		return list;
	}
	
	public Product select(String id) {
		return null;
	}
	
	public int insert(Product product) {
		return 0;
	}
	
	public int update(Product product) {
		return 0;
	}
	
	public int delete(String id) {
		return 0;
	}

}
