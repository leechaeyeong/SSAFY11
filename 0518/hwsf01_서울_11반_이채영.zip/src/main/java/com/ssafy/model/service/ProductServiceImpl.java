package com.ssafy.model.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepo repo;//필요해:의존성 + 스프링이 나에게 줘:주입

	@Override
	public List<Product> selectAll() {
		List<Product> list = new ArrayList<Product>();
		list = repo.selectAll();
		return list;
	}
	@Override
	public ProductRepo getRepo() {
		return null;
	}
	@Override
	public Product select(String id) {
		return null;
	}
	@Override
	public int insert(String id) {
		return 0;
	}
	@Override
	public int update(Product product) {
		return 0;
	}
	@Override
	public int delete(String id) {
		return 0;
	}
	
}
