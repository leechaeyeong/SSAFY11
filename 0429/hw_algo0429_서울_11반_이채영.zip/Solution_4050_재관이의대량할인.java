package swea;

import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Solution_4050_������Ǵ뷮���� {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int T=sc.nextInt();
		for (int tc = 1; tc <=T; tc++) {
			int n=sc.nextInt();
			Integer [] clo=new Integer[n];
			int sum=0;
			for (int i = 0; i < clo.length; i++) {
				clo[i]=sc.nextInt();
				sum+=clo[i];
			}
			Arrays.sort(clo,Collections.reverseOrder());
			for (int i = 0; i < clo.length; i++) {
				if(i+1<=n && (i+1)%3==0) {
					sum-=clo[i];
				}
			}
			System.out.println("#"+tc+" "+sum);
		}//end of testcase
	}//end of main
}//end of class
