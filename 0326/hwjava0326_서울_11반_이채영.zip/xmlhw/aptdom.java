package xmlhw;

import java.io.IOException;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class aptdom {

	public static void main(String[] args) {

		Document docObj = null;
		System.out.print("아파트 이름 입력 : ");
		Scanner sc = new Scanner(System.in);
		String input = sc.next();

		try {
			String xmlFile = "./src/xmlhw/AptDealHistory.xml";
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			docObj = builder.parse(xmlFile);
		
			String aptName = "아파트";
			String dong = "법정동";
			String cost = "거래금액";

			NodeList nodeList = docObj.getElementsByTagName(aptName);
			NodeList nodeList2 = docObj.getElementsByTagName(dong);
			NodeList nodeList3 = docObj.getElementsByTagName(cost);

			for (int i = 0; i < nodeList.getLength(); i++) {
				
				Node tmpNode = nodeList.item(i).getChildNodes().item(0);
				if (tmpNode.getNodeType() != Node.TEXT_NODE && tmpNode.getNodeType() != Node.CDATA_SECTION_NODE) {
					continue;
				}
				String nodeValue = tmpNode.getNodeValue(); // 아파트명
				

				Node tmpNode2 = nodeList2.item(i).getChildNodes().item(0);
				if (tmpNode2.getNodeType() != Node.TEXT_NODE && tmpNode2.getNodeType() != Node.CDATA_SECTION_NODE) {
					continue;
				}
				String nodeValue2 = tmpNode2.getNodeValue(); // 동명
				
				Node tmpNode3 = nodeList3.item(i).getChildNodes().item(0);
				if (tmpNode3.getNodeType() != Node.TEXT_NODE && tmpNode3.getNodeType() != Node.CDATA_SECTION_NODE) {
					continue;
				}
				String nodeValue3 = tmpNode3.getNodeValue(); // 거래금액
				
				
				if(nodeValue.contains(input)) {
					System.out.println("[아파트명] : " + nodeValue+", [법정동] : "+nodeValue2+", [거래금액] : "+nodeValue3);
				}
			}
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}// main
}
