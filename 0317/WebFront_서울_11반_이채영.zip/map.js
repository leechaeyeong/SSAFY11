/**
 * MyMap 생성자로 사용될 함수를 구현
 */

function MyMap(){
	this.map = new Object();
}

MyMap.prototype.put = function(key, value) {
	this.map[key] = value;
}
MyMap.prototype.get = function(key) {
	return this.map[key];
}
MyMap.prototype.clear = function() {
	for ( var i in this.map) {
		delete this.map[i];
	}
}
MyMap.prototype.remove = function(key) {
	delete this.map[key];
}
MyMap.prototype.size = function() {
	var count = 0;
	for ( var i in this.map) {
		count++;
	}
	return count;
}
