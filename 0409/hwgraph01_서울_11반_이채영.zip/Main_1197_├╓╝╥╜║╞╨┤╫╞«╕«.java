package graph;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Main_1197_�ּҽ��д�Ʈ�� {
	static class edge {
		int v1;
		int v2;
		int e;

		public edge(int v1, int v2, int e) {
			super();
			this.v1 = v1;
			this.v2 = v2;
			this.e = e;
		}

		@Override
		public String toString() {
			return "edge [v1=" + v1 + ", v2=" + v2 + ", e=" + e + "]";
		}

	}

	static edge[] adj;
	static int parent[];
	static int rank[];

	public static void main(String[] args) { // kruskal
		Scanner sc = new Scanner(System.in);
		int v = sc.nextInt();
		int e = sc.nextInt();

		// ���� �迭 �����
		adj = new edge[e];
		for (int i = 0; i < adj.length; i++) {
			adj[i] = new edge(sc.nextInt()-1, sc.nextInt()-1, sc.nextInt());
		}
		
		// ����
		Arrays.sort(adj, new Comparator<edge>() {

			@Override
			public int compare(edge o1, edge o2) {
				if (o1.e >= o2.e)
					return 1;
				else
					return -1;
			}
		});
		// ���Ȯ��
		for (int i = 0; i < adj.length; i++) {
			System.out.println(adj[i].toString());
		}
		parent = new int[v];
		rank = new int[v];
		// set ����
		for (int i = 0; i < v; i++) {
			makeSet(i);
		}
		// union
		int cnt = 0;
		int mst = 0; // ��� ��
		for (int i = 0; i < adj.length; i++) {
			edge out = adj[i];
			int a = findSet(out.v1);
			int b = findSet(out.v2);

			if (a != b) {

				union(a, b);
				cnt++;
				mst += out.e;

				if (cnt == v - 1)
					break;
			}
		}
		System.out.println(mst);

	}// end of main

	private static void makeSet(int i) {
		parent[i] = i;
	}

	private static int findSet(int i) {
		if (i == parent[i])
			return i;
		else {
			parent[i] = findSet(parent[i]); //
			return parent[i];
		}
	}

	private static void union(int px, int py) { //
		
		if (rank[px] > rank[py]) {
			parent[py] = px; // 
		} else {
			parent[px] = py;
			if (rank[px] == rank[py])
				rank[py]++; //
		}
	}

}// end of class
