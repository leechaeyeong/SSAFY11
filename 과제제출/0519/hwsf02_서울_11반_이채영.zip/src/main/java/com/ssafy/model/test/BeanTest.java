package com.ssafy.model.test;

import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;

public class BeanTest {

	public static void main(String[] args) {
		ProductService service = new ProductServiceImpl();
		System.out.println("호출 시작 : service - selectAll()");
		service.selectAll();
		System.out.println("호출 종료 : service - selectAll()");
		
	}

}
