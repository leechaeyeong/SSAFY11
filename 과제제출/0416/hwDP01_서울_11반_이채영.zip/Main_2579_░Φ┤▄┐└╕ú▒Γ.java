package DP;

import java.util.Arrays;
import java.util.Scanner;

public class Main_2579_��ܿ����� {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

		int num[] = new int[n + 1];
		for (int i = 1; i < num.length; i++) {
			num[i] = sc.nextInt();
		}

		int d[] = new int[n + 1]; // ���� ����� ��ġ���� �ִ��� �ֱ�

		d[1] = num[1]; // �ʱⰪ ��ġ

		for (int i = 2; i < d.length; i++) {
			if(i-3>=0)
				d[i] = Math.max(num[i]+ num[i - 1] + d[i - 3] , d[i - 2] + num[i]);
			else
				d[i] = d[i-1]+num[i];
		}
		System.out.println(Arrays.toString(d));
		System.out.println(d[n]);

	}// end of main
}// end of class
