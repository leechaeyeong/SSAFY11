public class ProductTest {
	public static void main(String[] args) {
		
		ProductMgr mgr = new ProductMgr();
		boolean flag= false;
		while(true) {
			flag = mgr.menu();
			if(flag)
				break;
		}
	}
}
