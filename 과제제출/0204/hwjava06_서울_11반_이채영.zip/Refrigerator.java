
public class Refrigerator extends Product {

	private int vol;

	public Refrigerator(int serialNum, String name, int cost, int count, int vol) {
		super(serialNum, name, cost, count);
		this.vol = vol;
	}

	public int getVol() {
		return vol;
	}

	public void setVol(int vol) {
		this.vol = vol;
	}

	public String toString() {
		return "Refrigerator [serialNum=" + getSerialNum() + ", name=" + getName() + ", cost=" + getCost() + ", count="
				+ getCount() + "vol=" + vol + "]";
	}

}
