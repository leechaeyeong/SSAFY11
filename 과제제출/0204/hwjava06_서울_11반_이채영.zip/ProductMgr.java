

import java.util.ArrayList;
import java.util.Scanner;

public class ProductMgr {
	
	
	ArrayList<Product> prodList = new ArrayList<>();
	
	Scanner scan = new Scanner(System.in);
	
	public boolean menu() {
		System.out.println("메뉴를 선택하세요");
		System.out.println("0. 종료하기");
		System.out.println("1. 데이터 추가");
		System.out.println("2. 데이터 전체 검색");
		System.out.println("3. 상품번호로 검색");
		System.out.println("4. 상품명으로 검색");
		System.out.println("5. TV만 검색");
		System.out.println("6. Refrigerator만 검색");
		System.out.println("7. 상품번호로 상품 삭제");
		System.out.println("8. 전체 재고의 상품 금액 검색");

		int m = scan.nextInt();
		
		switch(m) {
		
		case 0 :
			return true;
		
		case 1 :
			input();
			break;
			
		case 2 :
			searchAll();
			break;
			
		case 3 :
			searchNum();
			break;
		
		case 4 :
			searchName();
			break;
			
		case 5 :
			searchTV();
			break;
		
		case 6 :
			searchRef();
			break;
			
		case 7 :
			deleteNum();
			break;
			
		case 8 :
			searchPrice();
			break;
		}
		return false;
	}
	
	public void input() {
		// TODO Auto-generated method stub
		System.out.println("TV : 1\tRefrigerator : 2");
		
		int i = scan.nextInt();
		
		int num;
		String name;
		int price, stock;
		
		System.out.print("제품번호 : "); num = scan.nextInt();
		System.out.print("제품명 : "); name = scan.next();
		System.out.print("가격 : "); price = scan.nextInt();	
		System.out.print("재고 : "); stock = scan.nextInt();
		
		
		if(i==1) { 
			System.out.print("inch : "); int inch = scan.nextInt();
			System.out.print("type : "); String type = scan.next();
			
			prodList.add(new TV(num, name, price, stock, inch, type));
		}
		
		else { 
			System.out.print("volume 입력 : "); int volume = scan.nextInt();
			prodList.add(new Refrigerator(num, name, price, stock,volume));
		}
		
		
		
	}

	private void searchPrice() {
		int sum = 0;
		for (int i = 0; i < prodList.size(); i++) {
			sum += (prodList.get(i).getCost() * prodList.get(i).getCount());
		}
		System.out.println("전체 재고의 상품 금액 : "+sum);
		
	}
	

	private void deleteNum() {
		System.out.print("삭제할 제품 번호 : ");
		int del = scan.nextInt();
		boolean flag = false;
		
		for (int i = 0; i < prodList.size(); i++) {
			if(prodList.get(i).getSerialNum()==del) {
				flag = true;
				prodList.remove(i);
			}
		}
		if(!flag)
			System.out.println("해당 제품 없음");
		else 
			System.out.println("삭제 됨");
		
	}


	public void searchRef() {
		
		boolean flag = false;
		
		for (int i = 0; i < prodList.size(); i++) {
			if(prodList.get(i) instanceof Refrigerator) {
				flag = true;
				System.out.println(prodList.get(i).toString());
			}
		}
		
		if(!flag)
			System.out.println("Refriegerator 제품이 없음");
		else
			System.out.println("검색 완료");
		
		
	}
	

	private void searchTV() {
		
		boolean flag = false;
		
		for (int i = 0; i < prodList.size(); i++) {
			if(prodList.get(i) instanceof TV) {
				flag = true;
				System.out.println(prodList.get(i).toString());
			}
		}
		
		if(!flag) 
			System.out.println("TV 제품 없음");

		else 
			System.out.println("검색완료");
		
	}
	

	public void searchName() {
		
		System.out.print("검색할 제품명 : ");
		String name = scan.next();
		
		boolean flag = false;
		
		for (int i = 0; i < prodList.size(); i++) {
			if(prodList.get(i).getName().contains(name)) {
				flag = true;
				System.out.println(prodList.get(i).toString());
				break;
			}
		}
		
		if(!flag)
			System.out.println("해당 제품이 없음");

		else 
			System.out.println("검색완료");
		
		
	}

	public void searchNum() {
		
		System.out.print("검색할 제품 번호 : ");
		int num = scan.nextInt();
		
		boolean flag = false;
		
		for (int i = 0; i < prodList.size(); i++) {
			if(prodList.get(i).getSerialNum()==num) {
				flag = true;
				System.out.println(prodList.get(i).toString());
				break;
			}
		}
		
		if(!flag)
			System.out.println("해당 제품이 없음");

		else 
			System.out.println("검색완료");

	}

	public void searchAll() {
	
		boolean flag = false;
		
		if(prodList.size()==0) {
			System.out.println("제품이 없음");
			return;
		}
		
		for (int i = 0; i < prodList.size(); i++) {
			System.out.println(prodList.get(i).toString());
		}
		
		System.out.println("검색완료");
		
	}

}
