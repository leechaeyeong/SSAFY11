
public class TV extends Product {

	private int inch;
	private String type;

	public TV(int serialNum, String name, int cost, int count, int inch, String type) {
		super(serialNum, name, cost, count);
		this.inch = inch;
		this.type = type;
	}

	public String toString() {
		return "TV [serialNum=" + getSerialNum() + ", name=" + getName() + ", cost=" + getCost() + ", count="
				+ getCount() + "inch=" + inch + ", type=" + type + "]";
	}

}
