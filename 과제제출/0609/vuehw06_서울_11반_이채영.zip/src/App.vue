<template>
  <div id="app">
    <nav-header></nav-header>
    <h2 class="text-center">Vue를 이용한 사원관리</h2>
    <router-view></router-view>
  </div>
</template>

<script>
import NavHeader from '@/components/layout/Header.vue';
export default {
  name: 'App',
  components: {
    NavHeader,
  },
}
</script>
<style>

</style>
