<template>
  <div>

          <!-- 검색창 : <input type="text" v-model="searchword"> <button @click="search">검색</button> -->

          <div v-if="items.length">
              <table style=" width: 50%; ">
                <tr style="background-color: rgb(71, 115, 180); color: white;">
                  <th>사원 아이디</th>
                  <th>사원명</th>
                  <th>부서</th>
                  <th>직책</th>
                  <th>연봉</th>
                </tr>

                <list-row
                  v-for="(item, index) in items"
                  :key="`${index}_items`"
                  :id="item.id"
                  :name="item.name"
                  :dept="item.dept"
                  :position="item.position"
                  :sal="item.sal"
                />
              </table>
          </div>
          <div v-else>
              등록된 사원이 없습니다
          </div>

    </div>

</template>

<script>
import { mapGetters } from 'vuex';
import ListRow from '@/components/include/Row.vue';


export default {
    name: 'list'
    ,  components: {
          ListRow,
      }
    ,   computed: {
           ...mapGetters(['items']),
     },
      created() {
          this.$store.dispatch('getHrms');
        } 
    //  , methods:{
          //       search(){
          //           let word2 = this.searchword;
          //           this.items = this.items.filter(function(val, idx){
          //               if(val.name.indexOf(word2) > -1){
          //                   return true;
          //               }
          //           });
          //       }
          // } // end of methods

}
</script>

<style>

</style>