<template>
  <div>
    <div>
      <h1 class="text-center">메인페이지</h1>
    </div>
    <div>만든이 : 이채영</div>
  </div>
</template>

<script>
export default {
  name: "index",
};
</script>

<style>
</style>
