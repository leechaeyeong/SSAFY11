<template>
  <div>
    <detail />
  </div>
</template>

<script>

import Detail from '@/components/include/Detail.vue';
export default {
  name: 'read',
  components: {
    Detail,
  },
  
  created() {
      this.$store.dispatch('getHrm', `/hrm/${this.$route.query.id}`);
  },
};
</script>

<style></style>
