<template>
  <tr>
    <td>{{ id }}</td>
    <td>
      <router-link :to="`/read?id=${id}`">{{ name }}</router-link>
    </td>
    <td>{{ dept }}</td>
    <td>{{ position }}</td>
    <td>{{ sal }}</td>
  </tr>
</template>

<script>

export default {
  name: 'row',
  props: {
    id:  Number ,
    name:  String ,
    dept:  String ,
    position: String ,
    sal:  String ,
  },

};
</script>
