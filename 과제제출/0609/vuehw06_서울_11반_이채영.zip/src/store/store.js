import Vue from 'vue';
import Vuex from 'vuex';
import http from '@/util/http-common';

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    items: [],
    item: {},
  },
  getters: {
    items(state) {
      return state.items;
    },
    item(state) {
      return state.item;
    },
  },
  mutations: {
    setHrms(state, payload) {
      state.items = payload;
    },
    setHrm(state, payload) {
      state.item = payload;
    },
  },
  actions: {
    getHrms(context) {
      http
        .get('/hrm')
        .then(({ data }) => {
          context.commit('setHrms', data);
        })
        .catch(() => {
          alert('에러가 발생했습니다.');
        });
    },
    getHrm(context, payload) {
      http.get(payload).then(({ data }) => {
        context.commit('setHrm', data);
      });
    },
  },
});
