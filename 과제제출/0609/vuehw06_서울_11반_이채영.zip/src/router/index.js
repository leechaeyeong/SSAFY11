import Vue from "vue";
import VueRouter from "vue-router";

import Index from '@/components/page/Index.vue';
import List from '@/components/page/List.vue';
import Create from '@/components/page/Create.vue';
import Read from '@/components/page/Read.vue';
//import Update from '@/components/page/Update.vue';
import Delete from '@/components/page/Delete.vue';

Vue.use(VueRouter);

export default new VueRouter({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'Index',
      component: Index,
    },
    {
      path: '/list',
      name: 'list',
      component: List,
    },
    {
      path: '/create',
      name: 'create',
      component: Create,
    },
    {
      path: '/read',
      name: 'read',
      component: Read,
    },
    // {
    //   path: '/update',
    //   name: 'update',
    //   component: Update,
    // },
    {
      path: '/delete',
      name: 'delete',
      component: Delete,
    },
  ],
});