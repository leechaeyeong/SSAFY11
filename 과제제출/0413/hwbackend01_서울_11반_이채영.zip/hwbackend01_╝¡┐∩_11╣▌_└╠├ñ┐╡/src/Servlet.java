

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/product")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 1. data get 받을때 깨짐
		request.setCharacterEncoding("utf-8"); // 넘어오는 데이터를 uft8로 받음 post일때만 사용가능
		String productname = request.getParameter("productname");
		String productcost = request.getParameter("productcost");
		String productdes = request.getParameter("productdes");
						
		// 2. logic
		//String colors[] = {"navyblue","orange","blue","red"};
		// 3. response page
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter(); 
		out.println("<html>");
		out.println("	<body>");
		out.println("상품명 : "+productname + 
				" | 상품가격 : "+productcost+"원"+
				" | 상품설명 : "+productdes);

		out.println("	</body>");
		out.println("</html>");
	}

}
