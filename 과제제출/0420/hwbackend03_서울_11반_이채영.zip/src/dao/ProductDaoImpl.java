package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dto.ProductDto;
import util.DBUtil;

public class ProductDaoImpl implements ProductDao{
	@Override
	public void writeArticle(ProductDto productDto) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("insert into product (num, name, price, description) \n");
			insertMember.append("values (?, ?, ?, ?)");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setInt(1, productDto.getNum());
			pstmt.setString(2, productDto.getName());
			pstmt.setInt(3, productDto.getPrice());
			pstmt.setString(4, productDto.getDescription());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

	@Override
	public List<ProductDto> listArticle(String key, String word) throws SQLException {
		List<ProductDto> list = new ArrayList<ProductDto>();
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select num, name, price, description \n");
			sql.append("from product \n");
			if(!word.isEmpty()) {
				if("name".equals(key)) {
					sql.append("where name like ? \n");
				} else {
					sql.append("where " + key + " = ? \n");
				}
			}
			sql.append("order by num desc \n");
			pstmt = conn.prepareStatement(sql.toString());
			if(!word.isEmpty()) {
				if("name".equals(key))
					pstmt.setString(1, "%" + word + "%");
				else
					pstmt.setString(1, word);
			}
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ProductDto productDto = new ProductDto();
				productDto.setNum(rs.getInt("num"));
				productDto.setName(rs.getString("name"));
				productDto.setPrice(rs.getInt("price"));
				productDto.setDescription(rs.getString("description"));
				
				
				list.add(productDto);
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return list;
	}

	@Override
	public ProductDto getArticle(int num) throws SQLException {
		ProductDto productDto = null;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select num, name, cost, description \n");
			sql.append("from product \n");
			sql.append("where num = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if(rs.next()) {

				productDto = new ProductDto();
				productDto.setNum(rs.getInt("num"));
				productDto.setName(rs.getString("name"));
				productDto.setPrice(rs.getInt("price"));
				productDto.setDescription(rs.getString("description"));
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return productDto;
	}

	@Override
	public void modifyArticle(ProductDto productDto) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("update product \n");
			insertMember.append("set name = ?, price = ?, description=? \n");
			insertMember.append("where product_num = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, productDto.getName());
			pstmt.setInt(2, productDto.getPrice());
			pstmt.setString(3, productDto.getDescription());
			pstmt.setInt(4, productDto.getNum());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

	@Override
	public void deleteArticle(int num) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("delete from product \n");
			insertMember.append("where num = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}
}
