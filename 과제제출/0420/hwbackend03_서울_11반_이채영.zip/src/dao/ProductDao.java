package dao;

import java.sql.SQLException;
import java.util.List;

import dto.ProductDto;

public interface ProductDao {
	public void writeArticle(ProductDto productDto) throws SQLException;
	public List<ProductDto> listArticle(String key, String word) throws SQLException;
	
	public ProductDto getArticle(int num) throws SQLException;
	public void modifyArticle(ProductDto productDto) throws SQLException;
	public void deleteArticle(int num) throws SQLException;
}
