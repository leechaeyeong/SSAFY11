package service;

import java.util.List;

import dto.ProductDto;

public interface ProductService {
	public void writeArticle(ProductDto productDto) throws Exception;
	public List<ProductDto> listArticle(String key, String word) throws Exception;
	
	public ProductDto getArticle(int product_num) throws Exception;
	public void modifyArticle(ProductDto productDto) throws Exception;
	public void deleteArticle(int product_num) throws Exception;
}
