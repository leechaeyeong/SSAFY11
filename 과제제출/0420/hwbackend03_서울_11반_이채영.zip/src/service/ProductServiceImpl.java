package service;

import java.util.List;

import dto.ProductDto;
import dao.ProductDao;
import dao.ProductDaoImpl;


public class ProductServiceImpl implements ProductService{

	private ProductDao productDao;
	
	public ProductServiceImpl() {
		productDao = new ProductDaoImpl();
	}

	@Override
	public void writeArticle(ProductDto productDto) throws Exception {
		if(productDto.getName() == null || productDto.getDescription() == null) {
			throw new Exception();
		}
		productDao.writeArticle(productDto);
	}

	@Override
	public List<ProductDto> listArticle(String key, String word) throws Exception {
		key = key == null ? "" : key;
		word = word == null ? "" : word;
		return productDao.listArticle(key, word);
	}

	@Override
	public ProductDto getArticle(int num) throws Exception {
		return productDao.getArticle(num);
	}

	@Override
	public void modifyArticle(ProductDto productDto) throws Exception {
		productDao.modifyArticle(productDto);
	}

	@Override
	public void deleteArticle(int num) throws Exception {
		productDao.deleteArticle(num);
	}

}
