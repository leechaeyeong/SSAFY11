package com.ssafy.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.model.ProductDto;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;

@WebServlet("/main.do")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ProductService productService;
	
	public void init() {
		productService = new ProductServiceImpl();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String root = request.getContextPath();
		String path = "/main.jsp";
		String act = request.getParameter("act");
		
		if("mvinsert".equals(act)) {
			path = "/product/insertProduct.jsp";
			redirect(response, path, root);
		} else if("mvsearchlist".equals(act)) {
			searchList(request,response);
		} else if("mvsearchproduct".equals(act)) {
			path = "/product/searchProduct.jsp";
			redirect(response, path, root);
		} else if("mvdelete".equals(act)) {
			path = "/product/deleteProduct.jsp";
			redirect(response, path, root);
		} else if("insert".equals(act)) {
			insertProduct(request,response);
		} else if("searchproduct".equals(act)) {
			searchProduct(request,response);
		} else if("delete".equals(act)) {
			deleteProduct(request,response);
		} else if("opt".equals(act)) {
			searchListOpt(request,response);
		} else if("mvmain".equals(act)) {
			redirect(response, path, root);
		}
	}

	private void searchListOpt(HttpServletRequest request, HttpServletResponse response) {
		String path = "/main.jsp";
		String key = request.getParameter("key");
		String word = request.getParameter("word");
		try {
			List<ProductDto> list = productService.searchListOpt(key, word);
			request.setAttribute("optList", list);
			request.setAttribute("check", 1);
			path = "/product/searchList.jsp";
			foward(request, response, path);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void deleteProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/main.jsp";
		String root = request.getContextPath();
		int pcode = Integer.parseInt(request.getParameter("productcode"));
		try {
			productService.deleteProduct(pcode);
			path = "/product/deleteSuccess.jsp";
			redirect(response, path, root);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "상품 삭제 실패!");
			path = "/error.jsp";
			foward(request, response, path);
		}
	}

	private void searchList(HttpServletRequest request, HttpServletResponse response) {
		String path = "/main.jsp";

		try {
			List<ProductDto> list = productService.searchList();
			request.setAttribute("products", list);
			request.setAttribute("check", 0);
			path = "/product/searchList.jsp";
			foward(request, response, path);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private void searchProduct(HttpServletRequest request, HttpServletResponse response) {
		String path = "/main.jsp";
		int pcode = Integer.parseInt(request.getParameter("productcode"));
		
		try {
			ProductDto product = productService.searchProduct(pcode);
			request.setAttribute("product", product);
			path = "/product/searchSuccess.jsp";
			foward(request, response, path);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void insertProduct(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String path = "/main.jsp";
		String root = request.getContextPath();
		
		String name = request.getParameter("productname");
		int price = Integer.parseInt(request.getParameter("productprice"));
		String comment = request.getParameter("productcomment");
		
		try {
			productService.insertProduct(name, price, comment);
			path = "/product/insertSuccess.jsp";
			request.getRequestDispatcher(path).forward(request, response);
		} catch (ServletException | SQLException e) {
			e.printStackTrace();
			request.setAttribute("msg", "상품 입력 실패!");
			path = "/error.jsp";
			foward(request, response, path);
		}
	}

	private void redirect(HttpServletResponse response, String path, String root) throws IOException {
		response.sendRedirect(root + path);
	}

	private void foward(HttpServletRequest request, HttpServletResponse response, String path)
			throws ServletException, IOException {
		request.getRequestDispatcher(path).forward(request, response);
	}
	
}
