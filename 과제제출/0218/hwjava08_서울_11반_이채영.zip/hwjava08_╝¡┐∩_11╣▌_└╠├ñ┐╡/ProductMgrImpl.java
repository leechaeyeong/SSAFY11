package hw08;
import java.util.ArrayList;
import java.util.Scanner;

public class ProductMgrImpl implements IProductMgr{
	ArrayList<Product> products = new ArrayList<Product>();
	
	@Override
	public void inputData(Scanner sc) {
		// TODO Auto-generated method stub
		System.out.println("1.  상품정보 입력");
		System.out.println("=============== 데이터 입력 =========================================");
		System.out.println("1. TV \t 2.냉장고  선택해 주세요");
		int producttype = sc.nextInt();
		if (producttype == 1) { // tv
			System.out.print("제품 번호 : ");
			int serialNum = sc.nextInt();
			System.out.print("제품 이름 : ");
			String name = sc.next();
			System.out.println("제품 가격 : ");
			int  price = sc.nextInt();
			System.out.println("제품 수량 : ");
			int num = sc.nextInt();
			System.out.println("인치 : ");
			int inch = sc.nextInt();
			products.add(new TV(serialNum, name,  price, num,  inch));
			
		} else if (producttype == 2) { // Magazine
			System.out.print("제품 번호 : ");
			int serialNum = sc.nextInt();
			System.out.print("제품 이름 : ");
			String name = sc.next();
			System.out.println("제품 가격 : ");
			int  price = sc.nextInt();
			System.out.println("제품 수량 : ");
			int num = sc.nextInt();
			System.out.println("용량 : ");
			int vol = sc.nextInt();
			products.add(new Refrigerator(serialNum, name,  price, num,  vol));
		} else
			System.out.println("잘못된 입력입니다");
		System.out.println("\n\n 아무 키나 입력해 주세요");
	}
	@Override
	public void findAll() {
		// TODO Auto-generated method stub
		System.out.println("2.  데이터 전체 검색");
		for (int i = 0; i < products.size(); i++) {
			System.out.println(products.get(i).toString());
		}
		System.out.println(" 아무 키나 입력해 주세요");
	}
	@Override
	public void findSerialNum(Scanner sc) {
		// TODO Auto-generated method stub
		System.out.println("3.  상품번호로 정보 검색");
		int input = sc.nextInt();
		for (int i = 0; i < products.size(); i++) {
			
			if(products.get(i).getSerialNum() == input)
			System.out.println(products.get(i).toString());
		}
		System.out.println(" 아무 키나 입력해 주세요");
	}
	
	public void findName(Scanner sc) {
		// TODO Auto-generated method stub
		System.out.println("4.  상품이름으로 정보 검색");
		String input = sc.next();
		for (int i = 0; i < products.size(); i++) {
			//if(superbooks[i].getIsbn().equals(input))
			if(products.get(i).getName().contains(input))
			System.out.println(products.get(i).toString());
		}
		System.out.println(" 아무 키나 입력해 주세요");
	}
	
	@Override
	public void findTV() {
		// TODO Auto-generated method stub
		System.out.println("5.  TV만 검색");
		for (int i = 0; i < products.size(); i++) {
			if(products.get(i) instanceof TV)
				System.out.println(products.get(i).toString());
		}
		System.out.println(" 아무 키나 입력해 주세요");
	}
	
	@Override
	public void findRefri() {
		// TODO Auto-generated method stub
		System.out.println("6.  냉장고만 검색");
		
		for (int i = 0; i < products.size(); i++) {
			if(products.get(i) instanceof Refrigerator)
				System.out.println(products.get(i).toString());
		}
		System.out.println(" 아무 키나 입력해 주세요");
	}
	@Override
	public void findRefriVol() { //6
		// TODO Auto-generated method stub
		System.out.println("7.  400L 이상의 냉장고 검색");
		for (int i = 0; i < products.size(); i++) {
			if(products.get(i) instanceof Refrigerator)
			{
				Refrigerator rf = (Refrigerator) products.get(i);
				if(rf.getVol()>=400)
					System.out.println(products.get(i).toString());
			}
		}
		System.out.println(" 아무 키나 입력해 주세요");
	}
	
	@Override
	public void findTVInch() {
		System.out.println("8.  50inch 이상의 TV 검색");
		for (int i = 0; i < products.size(); i++) {
			if(products.get(i) instanceof TV)
			{
				TV tv = (TV) products.get(i);
				if(tv.getInch()>=50)
					System.out.println(products.get(i).toString());
			}
		}
		System.out.println(" 아무 키나 입력해 주세요");
	}
	
	@Override
	public void changeNumPrice(Scanner sc) {
		// TODO Auto-generated method stub
		System.out.println("9. 상품번호와 가격을 입력받아 가격 변경하기");
		System.out.println("상품번호 입력 : ");
		int number = sc.nextInt();
		System.out.println("변경금액 입력 : ");
		int newprice = sc.nextInt();
		
		for (int i = 0; i < products.size(); i++) {
			if(products.get(i).getSerialNum() == number)
				products.get(i).setPrice(newprice);
		}
		System.out.println(" 아무 키나 입력해 주세요");
	}
	@Override
	public void deleteSerialNum(Scanner sc) {
		// TODO Auto-generated method stub
		System.out.println("10.  상품번호로 상품을 삭제하기");
		System.out.println("상품번호 입력 : ");
		int input = sc.nextInt();
		int i=0;
		for (i = 0; i < products.size(); i++) {
			if(products.get(i).getSerialNum() == input)
				products.remove(i);
				
		}
		
		System.out.println(" 아무 키나 입력해 주세요");
	}
	@Override
	public void allPrice() {
		// TODO Auto-generated method stub
		System.out.println("11. 전체 재고 상품금액 구하기");
		int sum = 0;
		for (int i = 0; i < products.size(); i++) {
			sum += products.get(i).getPrice();
		}System.out.println("금액 합계 :" + sum);
		System.out.println(" 아무 키나 입력해 주세요");
	}
	@Override
	public void printMenu() {
		// TODO Auto-generated method stub
		System.out.println("1.  상품정보 입력");
		System.out.println("2.  상품 전체 검색");
		System.out.println("3.  상품번호으로 정보 검색");
		System.out.println("4.  상품명으로 정보 검색");
		System.out.println("5.  tv만 검색");
		System.out.println("6.  냉장고만 검색");
		System.out.println("7.  400l 이상의 냉장고 검색");
		System.out.println("8.  50inch 이상 tv 검색");
		System.out.println("9.  상품번호와 가격입력 받아 상품 가격 변경하기");
		System.out.println("10. 상품번호로 상품 삭제");
		System.out.println("11. 전체 재고 상품 금액을 구하기");
	}
}