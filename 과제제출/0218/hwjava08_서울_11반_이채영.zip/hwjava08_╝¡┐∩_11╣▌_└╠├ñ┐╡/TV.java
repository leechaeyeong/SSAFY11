package hw08;

public class TV extends Product{
	private int inch;

	public TV(int serialNum, String name, int price, int num, int inch) {
		super(serialNum, name, price, num);
		this.inch = inch;
	}

	public int getInch() {
		return inch;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}

	@Override
	public String toString() {
		return "TV [serialNum=" + getSerialNum() + ", name=" + getName() + ", price=" + getPrice() + ", num=" + getNum() + "inch=" + inch + "]";
	}


	
}
