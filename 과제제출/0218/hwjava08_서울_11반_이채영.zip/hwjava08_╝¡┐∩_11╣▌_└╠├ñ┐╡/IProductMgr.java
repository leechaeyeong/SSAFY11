package hw08;

import java.util.Scanner;

public interface IProductMgr {
	
	abstract void inputData(Scanner sc);

	abstract void findAll();

	abstract void findSerialNum(Scanner sc);
	abstract void findName(Scanner sc);

	abstract void findTV();

	abstract void findRefri();

	abstract void findRefriVol();

	abstract void findTVInch();

	abstract void changeNumPrice(Scanner sc);

	abstract void deleteSerialNum(Scanner sc);

	abstract void allPrice();
	
	abstract void printMenu();

	
}
