package hw08;

import java.util.Scanner;

public class ProductTest {
	public static void main(String[] args) {
		
		ProductMgrImpl pml = new ProductMgrImpl();
		Product product1 = new Product(1, "��ǰ�̸�", 5000, 10);
		TV tv1 = new TV(2, "Ƽ��", 6000, 50, 90);
		Refrigerator rf1 = new Refrigerator(3, "�����", 8000, 60, 1000);
		
		pml.products.add(product1);
		pml.products.add(tv1);
		pml.products.add(rf1);
		
		Scanner sc = new Scanner(System.in);
		int input = 0;
		
		while (true) {
			pml.printMenu();
			input = sc.nextInt();


			switch (input) {
			case 1:
				pml.inputData(sc);
				sc.next();
				continue;
			case 2:
				pml.findAll();
				sc.next();
				continue;
			case 3:
				pml.findSerialNum(sc);
				sc.next();
				continue;
			case 4:
				pml.findName(sc);
				sc.next();
				continue;
			case 5:
				pml.findTV();
				sc.next();
				continue;
			case 6:
				pml.findRefri();
				sc.next();
				continue;
			case 7:
				pml.findRefriVol();
				sc.next();
				continue;
			case 8:
				pml.findTVInch();
				sc.next();
				continue;
			case 9:
				pml.changeNumPrice(sc);
				sc.next();
				continue;
			case 10:
				pml.deleteSerialNum(sc);
				sc.next();
				continue;
			case 11:
				pml.allPrice();
				sc.next();
				continue;
			}
		}
	}
}
