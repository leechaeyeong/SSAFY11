package hw08;

public class Refrigerator extends Product{
	private int vol;

	public Refrigerator(int serialNum, String name, int price, int num, int vol) {
		super(serialNum, name, price, num);
		this.vol = vol;
	}

	public int getVol() {
		return vol;
	}

	public void setVol(int vol) {
		this.vol = vol;
	}

	@Override
	public String toString() {
		return "Refrigerator [serialNum=" + getSerialNum() + ", name=" + getName() + ", price=" + getPrice() + ", num" + getNum() +"vol=" + vol + "]";
	}
	
}
