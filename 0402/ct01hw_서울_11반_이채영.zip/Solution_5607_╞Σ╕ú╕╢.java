package SWEA;

import java.util.Scanner;

public class Solution_5607_�丣�� {
	
    private static final int NUMBER = 1234567891;
    
    private static long cal(long n, int x) {
    	if (x == 0) 
    		return 1;
    	
    	long temp = cal(n, x / 2);
    	long ret = (temp * temp) % NUMBER;
    	
    	if (x % 2 == 0) 
    		return ret;
    	else 
    		return (ret * n) % NUMBER;
    }

    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
    	int T= sc.nextInt();
        for (int tc = 1; tc <= T; tc++) {
            
            int n = sc.nextInt(); // N
            int r =sc.nextInt(); // R
            
            long f[] = new long[n + 1];
            f[0] = 1;
            
            for (int i = 1; i <= n; i++) 
            	f[i] = (f[i - 1] * i) % NUMBER;

            long a = (f[r] * f[n - r]) % NUMBER;
            long b = cal(a, NUMBER - 2);

            System.out.println("#"+tc+ " "+(f[n] * b) % NUMBER);
        }
    }

}
