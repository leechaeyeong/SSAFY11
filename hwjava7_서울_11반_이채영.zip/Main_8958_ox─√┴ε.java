package ssafy_study;

import java.util.Scanner;

public class Main_8958_ox퀴즈 {
	public static void main(String[] args) {
		int test;
		Scanner scan= new Scanner(System.in);
		test=scan.nextInt();
		String[] ox= new String[test];
		
		
		for (int i = 0; i < test; i++) {
			ox[i]=scan.next();
		}
		
		int sum[] = new int[test];
		for (int i = 0; i < test; i++) {
			int k=1;
			for (int j = 0; j < ox[i].length(); j++) {
				if(ox[i].charAt(j)=='O')
				{	
					sum[i]=sum[i]+k;
					k++;
				}
				else 
				{
					k=1;
					continue;
				}
			}
		}
		for (int i = 0; i < sum.length; i++) {
			System.out.println(sum[i]);
		}
	}
}
