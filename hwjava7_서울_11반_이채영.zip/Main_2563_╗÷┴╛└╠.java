package ssafy_study;

import java.util.Scanner;

public class Main_2563_색종이 {
	public static void main(String[] args) {
		
		int[][] paper = new int[100][100];
		
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt(); //색종이수
		
		for (int i = 0; i < num; i++) {
			int x = scan.nextInt();
			int y = scan.nextInt();
			
			for (int j=x ; j < x+10; j++) {
				for (int k =y; k < y+10; k++) {
					paper[j][k] =1;
				}
			}
		}
		int cnt=0;
		for (int i = 0; i < paper.length; i++) {
			for (int j = 0; j < paper.length; j++) {
				if(paper[i][j] ==1)
					cnt++;
			}
		}
		System.out.println(cnt);
		
	}
}
