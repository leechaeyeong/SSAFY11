package ssafy_study;
import java.util.Scanner;

public class Main_2447_별찍기10 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt(); // 3 9 27 ...
		char[][] arr = new char[n][n]; // 출력배열
		StringBuilder sb= new StringBuilder();
		
		int i = 0, j = 0;
		
		for (int k = 0; k < n; k++) {
			for (int k2 = 0; k2 < n; k2++) {
				arr[k][k2] = '*';
			}
			
		}
		star(i, j, n, arr); // i j (첫좌표), 길이 l=n

		// 배열 출력
		for (int k = 0; k < n; k++) {
			for (int k2 = 0; k2 < n; k2++) {
				//System.out.print(arr[k][k2]);
				sb.append(arr[k][k2]);
			}
			//System.out.println();
			sb.append("\n");
		}
		System.out.println(sb);

		// 재귀에 넣은 값은 배열에 넣고 출력하기

	}// end of main
	public static char c = 'a';
	public static void star(int i, int j, int n, char[][] arr) {
		//System.out.println(i + " " + j + " " + n);
		//if (i == n || j == n) {
		if(n==1) {
			
			return;
		} else {
//			if (i == n / 3 && j == n / 3) {
//				System.out.println("들어가냐?");
//				for (int k = i; k < i + n / 3; k++) {
//					for (int k2 = j; k2 < j+ n / 3 ; k2++) {
//						arr[k][k2] = '/';
//					}
//				}
//				i--;
//				j--;
//				
//			} 
//			else {
				//arr[i][j] = '*';

				//if (i >= 0 && i < n / 3 && j >= 0 && j < n ) {
					star(i, j, n / 3, arr);
					star(i, j+ n / 3, n / 3, arr);
					star(i, j+ n / 3 * 2, n / 3, arr);
				//} 
				//else if (i >= n/3 && i < n/ 3 * 2 && j >= 0 && j < n ) 
				//{
					star(i + n / 3, j, n/3, arr);
					
					//빈칸	
					for (int k = i+n/3; k < i+n/3*2; k++) {
						for (int k2 = j+n/3; k2 < j+n/3*2; k2++) {
							arr[k][k2] = ' ';
						}
					}
					
					star(i + n / 3, j + n / 3 * 2, n/3, arr);
				//}

				//else if (i >= n / 3*2 && i < n && j >= 0 && j < n)
				//{
					star(i + n / 3 * 2, j, n/3, arr);
					star(i + n / 3 * 2, j + n / 3, n/3, arr);
					star(i + n / 3 * 2, j + n / 3 * 2, n/3, arr);
				//}
				

//			}
		}

	}// end of star
}// end of class