package ssafy_study;

import java.util.Scanner;

public class Main_1110_더하기사이클 {
	public static void main(String[] args) {
		
		
		int N;
		Scanner scan= new Scanner(System.in);
		N=scan.nextInt();
		
		int f1, s1; //10의 자리, 1의 자리
		int N2=0;
		int f2, s2;
		int cnt=0;
		
		
		while(true)
		{
			
			if(cnt==0)
				N2=N;
			
			f1 = N2/10; //2
			s1 = N2%10; //6
			
			N2 = f1+s1; //8
			f2 = N2/10; //0
			s2= N2%10; //8
			
			N2 = s1*10 + s2; //68
			cnt++;
			
			if(N==N2)
				break;
		}

		System.out.println(cnt);
		
	}
}

