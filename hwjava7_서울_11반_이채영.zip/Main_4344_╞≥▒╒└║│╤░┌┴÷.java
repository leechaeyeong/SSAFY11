package ssafy_study;

import java.util.Scanner;

public class Main_4344_평균은넘겠지 {
	public static void main(String[] args) {
		int C;
		Scanner scan= new Scanner(System.in);
		C= scan.nextInt(); //testcase
		
		double[] testres = new double[C]; //결과값
		
		for (int i = 0; i < C; i++) {
			
			int stdnum = scan.nextInt(); //학생수
			int[] score = new int[stdnum]; //점수
			int sum=0;
			double
			cnt=0;

			for (int j = 0; j < score.length; j++) {
				score[j]=scan.nextInt();
				sum+=score[j];
			}
			int avg = sum/stdnum; //평균
			
			for (int j = 0; j < score.length; j++) {
				if(avg < score[j])
					cnt++;
				
			}
			testres[i] = (cnt/stdnum)*100;
		}
		for (int i = 0; i < testres.length; i++) {
			System.out.println(String.format("%.3f",testres[i])+"%");
		}
		
		
	}//end of main
}
