package swea;

import java.util.ArrayList;
import java.util.Scanner;

public class Solution_4366_��������������� {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for (int tc = 1; tc <= T; tc++) {
			String ss = sc.next();
			String ts = sc.next();

			String[] srr = ss.split("");
			String[] trr = ts.split("");

			ArrayList<Integer> sres = new ArrayList<Integer>();
			ArrayList<Integer> tres = new ArrayList<Integer>();

			// 3����
			for (int k = 0; k < trr.length; k++) {
				if (trr[k].equals("0")) {

					trr[k] = "1";
					String tnum0 = "";
					for (int i = 0; i < trr.length; i++) {
						tnum0 = tnum0.concat(trr[i]);
					}
					
					tres.add(Integer.parseInt(tnum0, 3));
					//
					
					trr[k] = "2";
					tnum0 = "";
					for (int i = 0; i < trr.length; i++) {
						tnum0 = tnum0.concat(trr[i]);
					}

					tres.add(Integer.parseInt(tnum0, 3));

					// 3���� ����
					trr[k] = "0";

				} else if (trr[k].equals("1")) {

					trr[k] = "0";

					String tnum1 = "";
					for (int i = 0; i < trr.length; i++) {
						tnum1 = tnum1.concat(trr[i]);
					}
					tres.add(Integer.parseInt(tnum1, 3));
					//
					trr[k] = "2";

					tnum1 = "";
					for (int i = 0; i < trr.length; i++) {
						tnum1 = tnum1.concat(trr[i]);
					}
					
					tres.add(Integer.parseInt(tnum1, 3));
					// 3���� ����
					trr[k] = "1";

				} else { // 2

					trr[k] = "0";

					String tnum2 = "";
					for (int i = 0; i < trr.length; i++) {
						tnum2 = tnum2.concat(trr[i]);
					}

					tres.add(Integer.parseInt(tnum2, 3));

					trr[k] = "1";

					tnum2 = "";
					for (int i = 0; i < trr.length; i++) {
						tnum2 = tnum2.concat(trr[i]);
					}

					tres.add(Integer.parseInt(tnum2, 3));
					// 3���� ����
					trr[k] = "2";

				}
			}
			// 2����
			for (int i = 0; i < srr.length; i++) {
				if (srr[i].equals("0")) {
					
					srr[i] = "1";

					String snum0 = "";
					for (int j = 0; j < srr.length; j++) {
						snum0 = snum0.concat(srr[j]);
					}
					
					sres.add(Integer.parseInt(snum0, 2));

					srr[i] = "0";
				} else { // 1
					srr[i] = "0";
					
					String snum1 = "";
					for (int j = 0; j < srr.length; j++) {
						snum1 = snum1.concat(srr[j]);
					}
					
					sres.add(Integer.parseInt(snum1, 2));
					srr[i] = "1";
				}

			}
			boolean out = false;

			int res = 0;
			for (int i = 0; i < sres.size(); i++) {
				for (int j = 0; j < tres.size(); j++) {
					if (sres.get(i).equals(tres.get(j))) { // ??? �̰� ���̷���?
						res = sres.get(i);
						out = true;
						break;
					}
				}
				if (out)
					break;
			}
			System.out.println("#" + tc + " " + res);
		} // end of testcase
	}// end of main
}// end of class
