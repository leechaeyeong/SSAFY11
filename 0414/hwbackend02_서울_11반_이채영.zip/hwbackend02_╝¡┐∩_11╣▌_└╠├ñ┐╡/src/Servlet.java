

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/controller")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 1. data get 받을때 깨짐
		request.setCharacterEncoding("utf-8"); // 넘어오는 데이터를 uft8로 받음 post일때만 사용가능
		String productname = request.getParameter("productname");
		String productcost = request.getParameter("productcost");
		String productdes = request.getParameter("productdes");
		
			
		request.setAttribute("productname", productname);
		request.setAttribute("productcost", productcost);
		request.setAttribute("productdes", productdes);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/hw/controller.jsp");
		dispatcher.forward(request, response);
		
	}

}
