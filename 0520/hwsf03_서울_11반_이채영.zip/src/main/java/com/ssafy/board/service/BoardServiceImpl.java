package com.ssafy.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.board.dto.Board;
import com.ssafy.board.repository.BoardRepository;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	BoardRepository repo;
	
	@Override
	public int boardRegist(Board board) {
		int successCnt = repo.boardRegist(board);
		return successCnt;
	}

	@Override
	public List<Board> boardListNoPaging() {
		List<Board> list = repo.boardListNoPaging();
		return list;
	}

	@Override
	public Board boardDetail(String no) {
		Board board = repo.boardDetail(no);
		System.out.println(board.getSubject());
		return board;
	}

	@Override
	public int boardDelete(String no) {
		int successCnt = repo.boardDelete(no);
		return successCnt;
	}

	@Override
	public int boardModify(Board board) {
		int successCnt = repo.boardModify(board);
		return successCnt;
	}

}
