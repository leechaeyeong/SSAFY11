package com.ssafy.board.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.board.dto.Board;

@Repository
public class BoardRepositoryImpl implements BoardRepository {

	@Autowired
	SqlSession sqlSession;
	
	@Override
	public int boardRegist(Board board) {
		int successCnt = sqlSession.insert("BoardMapper.boardRegist", board);
		return successCnt;
	}

	@Override
	public List<Board> boardListNoPaging() {
		List<Board> list = sqlSession.selectList("BoardMapper.boardListNoPaging");
		return list;
	}

	@Override
	public Board boardDetail(String no) {
		Board board = sqlSession.selectOne("BoardMapper.boardDetail", no);
		return board;
	}

	@Override
	public int boardDelete(String no) {
		int successCnt = sqlSession.delete("BoardMapper.boardDelete", no);
		return successCnt;
	}
	
	public int boardModify(Board board) {
		int successCnt = sqlSession.insert("BoardMapper.boardUpdate", board);
		return successCnt;
	}

}
