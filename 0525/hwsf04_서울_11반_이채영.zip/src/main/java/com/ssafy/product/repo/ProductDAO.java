package com.ssafy.product.repo;

import java.util.List;

import com.ssafy.product.dto.Product;

public interface ProductDAO {
    public int insert(Product vo);
    public List<Product> selectAll();
    public Product select(int no);
	public int update(Product vo);
	public int delete(int no);
}



