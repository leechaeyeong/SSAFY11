package com.ssafy.product.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@Controller //나 컨트롤러!! ---> servlet-context.xml등록
public class ProductController {
	
	@Autowired
	ProductService service;

	
	@RequestMapping(value = "/form", method = RequestMethod.GET) //입력폼보기	
	public String form() {
	  return "product/inputForm";	
	}
	
	@RequestMapping(value = "/form", method = RequestMethod.POST) //DB입력
	public String formInsert(Product vo) {
		service.registry(vo);
		return "redirect:/list";	
	}
	
	
	@RequestMapping("/list")
	public String list(Model model) {		
		model.addAttribute("list",service.findAll());//뷰와 공유할 데이터를 영역에 저장	
		return "product/list";//JSP페이지 포워딩
	}
	
	@RequestMapping(value = "/upform" , method = RequestMethod.GET)//수정폼 보이기
	public String upform(int no, Model m) {
		m.addAttribute("product",service.find(no));
		return "product/editForm";
	}
	
	@RequestMapping(value = "/upform" , method = RequestMethod.POST)//DB수정하기
	public String update(Product vo) {
		service.modify(vo);		
		return "redirect:/list";
	}
	
	@RequestMapping("/delete")//DB삭제하기
	public String delete(int no) {
		service.remove(no);
		return "redirect:/list";
	}
	
	
}








