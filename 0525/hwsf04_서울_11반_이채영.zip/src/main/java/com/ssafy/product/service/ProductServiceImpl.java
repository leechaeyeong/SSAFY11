package com.ssafy.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.product.dto.Product;
import com.ssafy.product.repo.ProductDAO;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductDAO dao;

	@Override
	public int registry(Product product) {
		return dao.insert(product);
	}

	@Override
	public int modify(Product product) {
		return dao.update(product);
	}

	@Override
	public int remove(int no) {
		return dao.delete(no);
	}

	@Override
	public Product find(int no) {
		return dao.select(no);
	}

	@Override
	public List<Product> findAll() {		
		return dao.selectAll();
	}
}
