package homework2;

public class Product {
	private int pcode;
	private String pname;
	private int pcost;
	
	public Product() {}
	public Product(int pcode, String pname, int pcost) {
		super();
		this.pcode = pcode;
		this.pname = pname;
		this.pcost = pcost;
	}
	public int getPcode() {
		return pcode;
	}
	public void setPcode(int pcode) {
		this.pcode = pcode;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPcost() {
		return pcost;
	}
	public void setPcost(int pcost) {
		this.pcost = pcost;
	}
	@Override
	public String toString() {
		return "Product [pcode=" + pcode + ", pname=" + pname + ", pcost=" + pcost + "]";
	}

}
