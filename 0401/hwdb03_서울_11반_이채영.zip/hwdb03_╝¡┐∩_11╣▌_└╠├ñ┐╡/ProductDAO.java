package homework2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class ProductDAO {
	// 1. driver loading
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e){
			System.out.println("class loading fail");
		}
	}
	// 2. connection
	private Connection getConnection() throws SQLException {
		Connection con = DriverManager.getConnection
		("jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8","ssafy","ssafy");
		return con;
	}
	
	public void insertProduct(int pcode, String pname, int pcost) { // 삽입 (저장)
		Connection conn=null;
		PreparedStatement pstmt = null;
		try {
			conn = getConnection();
			String sql = "insert into products(pcode,pname,pcost) values(?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, pcode);
			pstmt.setString(2, pname);
			pstmt.setInt(3, pcost);
			pstmt.executeUpdate(); 
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			try {if(pstmt!=null)pstmt.close();}
			catch(Exception e) {};
			try {if(conn!=null)conn.close();}
			catch(Exception e) {};

		}
	}

	
	public int deleteProduct(int pcode) { // 삭제
		int successCnt =0;
		String sql = "delete from products where pcode =?";
		PreparedStatement pstmt =null;
		Connection conn = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, pcode);
			successCnt = pstmt.executeUpdate(); // ?
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			
			try {if(pstmt!=null)pstmt.close();}
			catch(Exception e) {};
			try {if(conn!=null)conn.close();}
			catch(Exception e) {};
		}
		return successCnt;
	}

	
	public void updateProduct(int pcode, String pname, int pcost) { // 수정
		String sql = "update products set pname= ?, pcost=? where pcode =?";
		PreparedStatement pstmt =null;
		Connection conn = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, pname);
			pstmt.setInt(2, pcost);
			pstmt.setInt(3, pcode);
			
			pstmt.executeUpdate(); // ?
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			
			try {if(pstmt!=null)pstmt.close();}
			catch(Exception e) {};
			try {if(conn!=null)conn.close();}
			catch(Exception e) {};
		}
		
	}

	
	public List<Product> allViewProduct() { // 전체 조회
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		Connection conn = null;
		ArrayList<Product> list = new ArrayList<>();
		
		try {
			conn = getConnection();
			String sql = "select * from products";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				list.add(new Product(rs.getInt("pcode"),
						rs.getString("pname"),
						rs.getInt("pcost")));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {if(rs!=null)rs.close();}
			catch(Exception e) {};
			try {if(pstmt!=null)pstmt.close();}
			catch(Exception e) {};
			try {if(conn!=null)conn.close();}
			catch(Exception e) {};
		}
		
		return list;
	}

	
	public Product findProduct(String pname) { // 상세 조회
		
		Product resPro = new Product(); // 결과값
		String sql = "select * from products "
				+ "where pname = ?";
		
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		Connection conn = null;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, pname);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				resPro.setPcode(rs.getInt("pcode"));
				resPro.setPname(rs.getString("pname"));
				resPro.setPcost(rs.getInt("pcost"));
			}
	
		} catch (SQLException e) {
			e.printStackTrace();
		} finally { 
			try {if(rs!=null)rs.close();}
			catch(Exception e) {};
			try {if(pstmt!=null)pstmt.close();}
			catch(Exception e) {};
			try {if(conn!=null)conn.close();}
			catch(Exception e) {};
		}
		
		return resPro;
	}
}
