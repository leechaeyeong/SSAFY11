package homework2;

import java.util.List;



public class Test {
	public static void main(String[] args) {
		ProductDAO dao = new ProductDAO();

		// 1. 상품정보 저장
		//dao.insertProduct(10, "라디오", 15); 
		
		// 2. 삭제
		//dao.deleteProduct(3);
		
		// 3. 상세 조회
//		Product find = dao.findProduct("키보드"); // 세부 출력
//		System.out.println(find); 
		
		// 4. 수정
		//dao.updateProduct(1, "에어팟", 20);
		
		// 5. 전체조회
		List<Product> list = dao.allViewProduct(); // 전체 출력
		for(Product p:list) {
			System.out.println(p);
		}
	
	}
}
