package com.ssafy.vue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.vue.dao.HrmDAO;
import com.ssafy.vue.dto.Hrm;

@Service
public class HrmServiceImpl implements HrmService {
	
    @Autowired
	private HrmDAO hrmDao;

    @Override
	public List<Hrm> retrieveHrm() {
		return hrmDao.selectHrm();
	}
    
  	@Override
	public boolean writeHrm(Hrm hrm) {
		return hrmDao.insertHrm(hrm) == 1;
	}

	@Override
	public Hrm detailHrm(int id) {
		return hrmDao.selectHrmById(id);
	}
//
//	@Override
//	@Transactional
//	public boolean updateBoard(Board board) {
//		return boardDao.updateBoard(board) == 1;
//	}
//
	@Override
	@Transactional
	public boolean deleteHrm(int id) {
		return hrmDao.deleteHrm(id) == 1;
	}
}