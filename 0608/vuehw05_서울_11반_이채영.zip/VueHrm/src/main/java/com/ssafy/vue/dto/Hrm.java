package com.ssafy.vue.dto;


public class Hrm {
	private String id;
	private String name;
	private String email ;
	private String hiredate;
	private String  admin ;
	private String position;
	private String dept ;
	private String sal ;
	private String commision;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getHiredate() {
		return hiredate;
	}
	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}
	public String getAdmin() {
		return admin;
	}
	public void setAdmin(String admin) {
		this.admin = admin;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getSal() {
		return sal;
	}
	public void setSal(String sal) {
		this.sal = sal;
	}
	public String getCommision() {
		return commision;
	}
	public void setCommision(String commision) {
		this.commision = commision;
	}
	@Override
	public String toString() {
		return "Hrm [id=" + id + ", name=" + name + ", email=" + email + ", hiredate=" + hiredate + ", admin=" + admin
				+ ", position=" + position + ", dept=" + dept + ", sal=" + sal + ", commision=" + commision + "]";
	}
	
	
}	