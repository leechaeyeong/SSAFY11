package com.ssafy.vue.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.vue.dto.Hrm;
@Mapper
public interface HrmDAO {
	public List<Hrm> selectHrm();
	public Hrm selectHrmById(int id);
	public int insertHrm(Hrm hrm);
//	public int updateBoard(Board board);
	public int deleteHrm(int id);
}