

create database if not exists ssafyvue;

use ssafyvue;

CREATE TABLE vue_hrm (
	id int NOT NULL AUTO_INCREMENT,
	name varchar(20),
    email varchar(20),
    hiredate varchar(20),
    admin varchar(20),
    position varchar(20),
    dept varchar(20),
    sal varchar(20),
    commision varchar(20),
    PRIMARY KEY (id)

); 
select * from vue_hrm;


