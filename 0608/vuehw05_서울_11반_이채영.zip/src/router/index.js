import Vue from "vue";
import VueRouter from "vue-router";

import List from '@/components/List.vue';
import Create from '@/components/Create.vue';
Vue.use(VueRouter);

export default new VueRouter({
  mode: 'history',
  routes: [
    // {
    //   path: '/',
    //   name: 'index',
    //   component: Index,
    // },
    {
      path: '/list',
      name: 'list',
      component: List,
    },
    {
      path: '/create',
      name: 'create',
      component: Create,
    },
    // {
    //   path: '/read',
    //   name: 'read',
    //   component: Read,
    // },
    // {
    //   path: '/update',
    //   name: 'update',
    //   component: Update,
    // },
    // {
    //   path: '/delete',
    //   name: 'delete',
    //   component: Delete,
    // },
  ],
});