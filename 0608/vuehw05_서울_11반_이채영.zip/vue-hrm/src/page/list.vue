<template>
  <div>

          <!-- 검색창 : <input type="text" v-model="searchword"> <button @click="search">검색</button> -->

          <div v-if="items.length">
              <table style=" width: 50%; ">
                <tr style="background-color: rgb(71, 115, 180); color: white;">
                  <th>사원 아이디</th>
                  <th>사원명</th>
                  <th>부서</th>
                  <th>직책</th>
                  <th>연봉</th>
                </tr>

                <list-row
                  v-for="(item, index) in items"
                  :key="`${index}_items`"
                  :id="item.id"
                  :name="item.name"
                  :dept="item.dept"
                  :position="item.position"
                  :sal="item.sal"
                />
              </table>
          </div>
          <div v-else>
              등록된 사원이 없습니다
          </div>

    </div>

</template>

<script>
import http from '@/util/http-common';
import ListRow from '@/components/Row.vue';


export default {
    name: 'list'
    ,  components: {
          ListRow,
      }
    , data: function(){
          return {
            items: []
           , searchword:""
          }
    }
     , created() {
          http
          .get('hrm')
           .then(({ data }) => {
           this.items = data;
           })
          .catch(() => {
              alert('에러가 발생했습니다.');
            });     
        } 
    //  , methods:{
          //       search(){
          //           let word2 = this.searchword;
          //           this.items = this.items.filter(function(val, idx){
          //               if(val.name.indexOf(word2) > -1){
          //                   return true;
          //               }
          //           });
          //       }
          // } // end of methods

}
</script>

<style>

</style>