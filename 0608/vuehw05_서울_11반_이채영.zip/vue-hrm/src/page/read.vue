<template>
  <div>
    <detail
      :id="item.id"
      :name="item.name"
      :dept="item.dept"
      :position="item.position"
      :sal="item.sal"
    />
  </div>
</template>

<script>
import http from '@/util/http-common';
import Detail from '@/components/Detail.vue';
export default {
  name: 'read',
  components: {
    Detail,
  },
  data: function() {
    return {
      item: {},
    };
  },
  created() {
    http.get(`/hrm/${this.$route.query.id}`).then(({ data }) => {
      this.item = data;
      console.dir(data);
    });
  },
};
</script>

<style></style>
