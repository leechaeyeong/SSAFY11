<template>
   <div>
        <create-form type="create" />
   </div>
</template>

<script>
import CreateForm from '@/components/Form.vue';

export default {
    name: 'create'
    ,components: {
    CreateForm,
  },
}
</script>

<style>

</style>