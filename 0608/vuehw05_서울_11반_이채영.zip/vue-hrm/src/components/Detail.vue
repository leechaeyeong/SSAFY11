<template>
  <div>
    <table class="table table-bordered w-50">
      <tr>
        <th>사원 아이디</th>
        <td>{{ id }}</td>
      </tr>
      <tr>
        <th>사원명</th>
        <td>{{ name }}</td>
      </tr>
      <tr>
        <th>부서</th>
        <td>{{ dept }}</td>
      </tr>
      <tr>
        <th>직책</th>
        <td>{{ position }}</td>
      </tr>
    </table>

    <br />
    <div class="text-center">
      <router-link to="/list"
        ><button class="btn btn-primary">목록</button></router-link
      >
      <!-- <router-link :to="'/update?no=' + no"
        ><button class="btn btn-primary">수정</button></router-link
      > -->
      <router-link :to="'/delete?id=' + id"
        ><button class="btn btn-primary">삭제</button></router-link
      >
    </div>
  </div>
</template>

<script>

export default {
  name: 'detail',
  props: {
    id: { type: Number },
    name: { type: String },
    dept: { type: String },
    position: { type: String },
  },

};
</script>
